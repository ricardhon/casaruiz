# Casa Ruiz

Site de casaruiz.pt — infraestrutura de presença digital para PME.
Figueira da Foz, Portugal.

HTML/CSS estático, sem build. Deploy automático via Vercel.

## Estrutura
- `index.html` — home
- `diagnostico/` `metodo/` `casos/` `sobre/` `contacto/` — páginas
- `assets/` — CSS, SVG (carta náutica, diagrama de camadas)
- `llms.txt` `robots.txt` `sitemap.xml` — camada SEO/GEO
